<?php
// Heading
$_['heading_title']    = 'Newsletter Subscription';

// Text
$_['text_account']     = 'Account';
$_['text_newsletter']  = 'Newsletter';
$_['text_success']     = 'Success: Your newsletter subscription has been successfully updated!';

// Entry
$_['entry_newsletter'] = 'Subscribe';