<?php
/**
 * @version		$Id: custom_in_stock.php 6115 2021-03-14 10:15:06Z mic $
 * @package		Custom in Stock
 * @author		mic - https://osworx.net
 * @copyright	2021 OSWorX
 * @license		AGPL - www.gnu.org/licenses/agpl-3.0.html
 *
 * note: only OC < 3.1.x
 */

$_['text_no_stock']			= '* Wie Kein Lagerstand *';
$_['entry_in_stock_status']	= 'Status Lagernd';
$_['help_in_stock_status']	= 'Wird angezeigt wenn Artikel lagernd ist. Wenn keine Auswahl, wird Standard &quot;Lagernd&quot; angezeigt';