<?php
/**
 * @version		$Id: dashboard.php 6115 2021-03-14 10:15:06Z mic $
 * @package		Language Translation German Backend
 * @author		mic - https://osworx.net
 * @copyright	2021 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Übersicht';

// Error
$_['error_install']	= '<p>Hinweis: der Installationsordner ist noch vorhanden!<br />Aus Sicherheitsgründen entweder löschen (oder umbenennen - dann Ordnerrechte auf 0644 oder 0444 anpassen).</p><div class="well well-sm card" style="font-size: 1.1em; padding: 10px;"><p>Mit Premiummodulen den neuen Shop erweitern.<ul class="fa-ul"><li><i class="fa-li fa fa-angle-double-right"></i><b>LEGAL</b> - rechtssichere Texte, Widerruf, korrekte Preisauszeichnungen usw.</li><li><i class="fa-li fa fa-angle-double-right"></i><b>PayPal PLus</b> - PayPal, Kreditkarten, Überweisung in einer Zahlungsart</li><li><i class="fa-li fa fa-angle-double-right"></i><b>Ratenzahlung by PayPal</b> - Für Kunden aus Deutschland den Einkauf möglich machen</li></ul>Das Alles und noch viel mehr bei <a href="https://osworx.net?ref=firstCall" target="_blank">OSWorX</a></p></div>';